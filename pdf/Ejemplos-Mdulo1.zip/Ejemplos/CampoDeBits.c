#include <stdio.h>
#include <stdlib.h>

#define CANT_FECHAS 20

// Definición de fecha: dd/mm/yy
struct fecha {
    unsigned dd : 5;
    unsigned mm : 4;
    unsigned yy : 15;  // Usar bits restantes
};

typedef struct fecha fecha_t;

/* Prototipos de funciones */
fecha_t crear_fecha();
void cargar_fecha(fecha_t*, unsigned, unsigned, unsigned);

/* Programa principal */
int main(){
    fecha_t fechas[CANT_FECHAS];
    fecha_t fechas_2[CANT_FECHAS];
    unsigned dd, mm, yy;

    // Crear fechas
    for(int i=0; i<CANT_FECHAS; i++)
        fechas[i] = crear_fecha();

    // Cargar fechas
    for(int i=0; i<CANT_FECHAS; i++){
        printf("Ingrese el día: ");
        scanf("%d", &dd);
        printf("Ingrese el mes: ");
        scanf("%d", &mm);
        printf("Ingrese el año: ");
        scanf("%d", &yy);
        cargar_fecha(fechas_2 + i, dd, mm, yy);
    }

    return 0;
}

// Crear fecha a partir de valores ingresados por teclado
fecha_t crear_fecha(){
    fecha_t fecha;
    unsigned aux;

    printf("Ingrese el día: ");
    scanf("%d", &aux);
    fecha.dd = aux;

    printf("Ingrese el mes: ");
    scanf("%d", &aux);
    fecha.mm = aux;

    printf("Ingrese el año: ");
    scanf("%d", &aux);
    fecha.yy = aux;

    return fecha;
}

// Cargar fecha a partir de valores recibidos como parámetros
void cargar_fecha(fecha_t* fecha, unsigned dd, unsigned mm, unsigned yy){

    if (dd >= 1 && dd <= 31)
        fecha->dd = dd;
    else {
        printf("Error: El día es inválido\n");
        return;
    }

    if (mm >= 1 && mm <= 12)
        fecha->mm = mm;
    else {
        printf("Error: El mes es inválido\n");
        return;
    }

    if (yy <= 30000)
        fecha->yy = yy;
    else
        printf("Error: El año es inválido\n");
}