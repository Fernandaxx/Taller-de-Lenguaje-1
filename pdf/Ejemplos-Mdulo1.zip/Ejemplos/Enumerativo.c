#include <stdio.h>
#include <stdlib.h>

// Define el tipo enum bool y lo renombra como bool_t
typedef enum bool {VERDADERO=1, FALSO=0,
                   TRUE=1, FALSE=0} bool_t;

// Define el tipo Universidad_t
typedef enum {UBA, UNLP, UNICEN} Universidad_t;

// Define el tipo enum color_RGB
enum color_RGB {NEGRO=0x000000,
                BLANCO=0xFFFFFF,
                ROJO=0xFF0000,
                VERDE=0x00FF00,
                AZUL=0x0000FF,
                AMARILLO=0xFFFF00};

// Define el tipo enum tono y declara la variable nota_musical
enum nota {LA='A', SI, DO, RE, MI, FA, SOL} nota_musical;

// Define un tipo enumerativo y declara la variable dispositivo
enum {WINDOWS, LINUX, MAC, ANDROID, IOS} dispositivo;

/* Prototipos de funciones */
void cambiar_universidad(Universidad_t*, Universidad_t);

/* Programa principal */
int main(){

    bool_t variable_booleana = FALSO;
    Universidad_t mi_universidad = UBA;
    enum color_RGB color = NEGRO;
    nota_musical = DO;
    enum tono nota_auxiliar = LA;
    dispositivo = WINDOWS;

    cambiar_universidad(&mi_universidad, UNLP);  // Enumerativo por referencia

    // Imprime "Mi universidad es 1"
    printf("Mi universidad es %d\n", mi_universidad);

    // Imprime "Mi universidad es UNLP"
    char* nombres[3] = {"UBA", "UNLP", "UNICEN"};  // Nombres de universidades
    printf("Mi universidad es %s\n", nombres[mi_universidad]);

    return 0;
}

// Cambiar el identificador de universidad
void cambiar_universidad(Universidad_t* mi_universidad, Universidad_t universidad){
    *mi_universidad = universidad;
}