#include <stdio.h>
#include <stdlib.h>

#define CANT_LUGARES 20

// Definición de lugar, con nombre y cantidad de habitantes
struct lugar {
    char nombre[50];
    unsigned int cant_habitantes;
};

typedef struct lugar lugar_t;

/* Prototipos de funciones */
lugar_t crear_lugar();
void cargar_lugar(lugar_t*);

/* Programa principal */
int main(){
    lugar_t lugares[CANT_LUGARES];
    lugar_t lugares_2[CANT_LUGARES];

    // Crear lugares
    for(int i=0; i<CANT_LUGARES; i++)
        lugares[i] = crear_lugar();

    // Cargar lugares
    for(int i=0; i<CANT_LUGARES; i++)
        cargar_lugar(lugares_2 + i);

    return 0;
}

// Crear un lugar a partir de valores ingresados por teclado
lugar_t crear_lugar(){
    lugar_t lugar;
    printf("Ingrese el nombre de la lugar: ");
    scanf("%s", lugar.nombre);
    printf("Ingrese la cantidad de habitantes: ");
    scanf("%d", &(lugar.cant_habitantes));
    return lugar;
}

// Cargar un lugar a partir de valores ingresados por teclado
void cargar_lugar(lugar_t* lugar){
    printf("Ingrese el nombre de la lugar: ");
    scanf("%s", lugar->nombre);
    printf("Ingrese la cantidad de habitantes: ");
    scanf("%d", &(lugar->cant_habitantes));
}