#include <stdio.h>
#include <stdlib.h>

// Identificación de tipos de objetos
enum tipo_objeto {PERSONA, VEHICULO, VIVIENDA};

// Definición de punto XY
struct puntoXY {
    unsigned short x;
    unsigned short y;
};

// Punto con hash para comparar si dos puntos son iguales
union punto {
    struct puntoXY xy;
    unsigned hash;
};

// Detalles de persona, vehículo o vivienda
union detalles {
    struct {
        char nombre[50];
        unsigned int edad;
    } detalles_persona;
    struct {
        char marca[50];
        char patente[10];
        unsigned int color;
    } detalles_vehiculo;
    struct {
        unsigned int area;
        unsigned int color;
    } detalles_vivienda;
};

// Objeto que puede ser persona, vehículo o vivienda
typedef struct objeto {
    enum tipo_objeto tipo;
    union punto punto;
    union detalles detalles;
} objeto_t;

/* Prototipos de funciones */
void imprimir_objeto(objeto_t);

/* Programa principal */
int main(){
    objeto_t persona = {PERSONA, {10, 30}, {"Lucas", 30}};

    objeto_t casa = {VIVIENDA, {20, 40}};
    casa.detalles.detalles_vivienda.area = 30;
    casa.detalles.detalles_vivienda.color = 0xFFEE44;

    imprimir_objeto(persona);
    imprimir_objeto(casa);

    if(persona.punto.hash == casa.punto.hash)
        printf("La persona se encuentra en la casa\n");

    return 0;
}

// Imprime los detalles del objeto, dependiendo del tipo de objeto
void imprimir_objeto(objeto_t objeto){
    switch (objeto.tipo) {
        case PERSONA:
            printf("Persona: %s, %d años\n",
                   objeto.detalles.detalles_persona.nombre,
                   objeto.detalles.detalles_persona.edad);
            break;
        case VEHICULO:
            printf("Vehículo: %s %s, color 0x%X\n",
                   objeto.detalles.detalles_vehiculo.marca,
                   objeto.detalles.detalles_vehiculo.patente,
                   objeto.detalles.detalles_vehiculo.color);
            break;
        case VIVIENDA:
            printf("Vivienda: %d m², color 0x%X\n",
                   objeto.detalles.detalles_vivienda.area,
                   objeto.detalles.detalles_vivienda.color);
            break;
        default: printf("Error: Tipo de objeto no reconocido\n");
    }
}